java -cp typer.jar com.tarena.typer.Typer
